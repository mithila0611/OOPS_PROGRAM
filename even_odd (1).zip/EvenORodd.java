/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.lang.*;
import java.util.Scanner;
public class EvenORodd{
    static void evenodd(int n){
        if(n%2==0){
             System.out.println(n+" is an even");
        }
        else{
             System.out.println(n+" is an odd");
        }
    }
	public static void main(String[] args) {
		int num;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number : ");
		num=input.nextInt();
		if(num>0) {
		   evenodd(num);
		}
        else {
	        System.out.println("Invalid input");
        }
	}
}